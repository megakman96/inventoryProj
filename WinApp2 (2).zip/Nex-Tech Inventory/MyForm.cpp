#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <tchar.h>
#using <mscorlib.dll>



#include "MainForm.h"
#include "MyForm1.cpp"
#include "ErrorPopupForm.cpp"
#include "ListForm.cpp"

using namespace System;
using namespace System::Windows::Forms;
[STAThread]


void main(array<String^>^ args)
{
	//String* BrandAr[,]= new String* [1,30];
	//array<System::String ^>^ arBrand = gcnew array<System::String ^>(30);
	//arBrand = gcnew array<System::String ^> {};

	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	WinApp2::MyForm form;
	WinApp2::ErrorPopupForm ^ dirFailPop = gcnew WinApp2::ErrorPopupForm;
	
	//LPCTSTR fName = "data";

	if (CreateDirectory("data", NULL)) {  //Directory created
										   //WinApp2::MyForm form;
		form.setBottomStatusMsg("Directory <data> Created");
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError()) {  //Directory already exists.
		form.setBottomStatusMsg("Directory <data> Already exists");
	}
	else {  //failed for some other reason
		form.setBottomStatusMsg("Other Error");
	}

	/*Create file called lists under data*/
	if (CreateDirectory("data/lists", NULL)) {  //Directory created
										  //WinApp2::MyForm form;
		form.setBottomStatusMsg("Directory <data/lists> Created");
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError()) {  //Directory already exists.
		form.setBottomStatusMsg("Directory <data/lists> Already exists");
	}
	else {  //failed for some other reason
		form.setBottomStatusMsg("Other Error");
	}
	/*Create file called comments under data*/

	if (CreateDirectory("data/comments", NULL)) {  //Directory created
												//WinApp2::MyForm form;
		form.setBottomStatusMsg("Directory <data/comments> Created");
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError()) {  //Directory already exists.
		form.setBottomStatusMsg("Directory <data/comments> Already exists");
	}
	else {  //failed for some other reason
		form.setBottomStatusMsg("Other Error");
	}

	if (CreateDirectory("data/main", NULL)) {  //Directory created
												   //WinApp2::MyForm form;
		form.setBottomStatusMsg("Directory <data/main> Created");
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError()) {  //Directory already exists.
		form.setBottomStatusMsg("Directory <data/main> Already exists");
	}
	else {  //failed for some other reason
		form.setBottomStatusMsg("Other Error");
	}

	if (CreateDirectory("data/temp", NULL)) {  //Directory created
											   //WinApp2::MyForm form;
		form.setBottomStatusMsg("Directory <data/temp> Created");
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError()) {  //Directory already exists.
		form.setBottomStatusMsg("Directory <data/temp> Already exists");
	}
	else {  //failed for some other reason
		form.setBottomStatusMsg("Other Error");
	}

	//make files for all lists





	//Make folders for setting lists data files
	//also for the historical records






	Application::Run(%form);
	//createDir("data");
}
