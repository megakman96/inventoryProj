#include "ConfirmationForm.h"
#include "ErrorPopupForm.h"
#include "ListForm.h"
//#include <unistd.h>
#include <Windows.h>
//#include <afxwin.h>
using namespace System;
using namespace System::IO;


#pragma once

namespace WinApp2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel1;
	public: System::Windows::Forms::DataGridView^  InventoryListView;
	private:

	protected:

	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel2;
	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel3;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  DeptDrop;

	private: System::Windows::Forms::ComboBox^  LocDrop;

	private: System::Windows::Forms::ComboBox^  UserDrop;

	private: System::Windows::Forms::ComboBox^  StatusDrop;
	public: System::Windows::Forms::ComboBox^  BrandDrop;
	private:




	private: System::Windows::Forms::TextBox^  InvTagBox;
	private: System::Windows::Forms::Label^  SNText;


	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::TextBox^  NameBox;

	private: System::Windows::Forms::TextBox^  SNBox;

	private: System::Windows::Forms::ComboBox^  TypeDrop;




	private: System::Windows::Forms::Button^  SaveButton;
	private: System::Windows::Forms::Button^  ClearButton;
	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel4;
	private: System::Windows::Forms::ComboBox^  SearchFilterDrop;
	private: System::Windows::Forms::Button^  clearSearchButton;
	private: System::Windows::Forms::TextBox^  SearchBox;
	private: System::Windows::Forms::Button^  SearchButton;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::DateTimePicker^  DOPDatePicker;
	private: System::Windows::Forms::DateTimePicker^  LPIDatePicker;
	private: System::Windows::Forms::Label^  BottomTitle;





	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  FileMenubutton;
	private: System::Windows::Forms::ToolStripMenuItem^  fileSettingsMenu;
	private: System::Windows::Forms::ToolStripMenuItem^  fileSaveMenu;
	private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  termsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  supportToolStripMenuItem;
	public: System::Windows::Forms::ToolStripStatusLabel^  bottomLeftStatus;
	private:
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	public:

		//Array ^ arBrand;
		array<System::String ^>^ arBrand = gcnew array<System::String ^>(30);
	private: System::Windows::Forms::ToolStripMenuItem^  listSettingMenuButton;
	public:
	private: System::Windows::Forms::ToolStripMenuItem^  preferencesSettingMenuButton;
	private: System::Windows::Forms::ToolStripMenuItem^  checksSettingMenuButton;
	public: System::Windows::Forms::ComboBox^  ModelDrop;

public:













public:












public:












	public:

		int rowCnt = 0;
private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel6;
private: System::Windows::Forms::RichTextBox^  commentsTextBox;
private: System::Windows::Forms::Button^  refreshUIButton;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::DataGridViewButtonColumn^  SNColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  InvTagColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  BrandColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  ModelColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  NameColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  StatusColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  UserColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  DepartmentColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  LocationColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  TypeColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  DOPColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  DoLPIColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  DateUpdatedColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  UpdateNum;














public:









	private:

	private:



	private: System::ComponentModel::IContainer^  components;





	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->tableLayoutPanel2 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->tableLayoutPanel3 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->LPIDatePicker = (gcnew System::Windows::Forms::DateTimePicker());
			this->DeptDrop = (gcnew System::Windows::Forms::ComboBox());
			this->LocDrop = (gcnew System::Windows::Forms::ComboBox());
			this->UserDrop = (gcnew System::Windows::Forms::ComboBox());
			this->StatusDrop = (gcnew System::Windows::Forms::ComboBox());
			this->BrandDrop = (gcnew System::Windows::Forms::ComboBox());
			this->InvTagBox = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SNText = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->NameBox = (gcnew System::Windows::Forms::TextBox());
			this->SNBox = (gcnew System::Windows::Forms::TextBox());
			this->TypeDrop = (gcnew System::Windows::Forms::ComboBox());
			this->SaveButton = (gcnew System::Windows::Forms::Button());
			this->ClearButton = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->DOPDatePicker = (gcnew System::Windows::Forms::DateTimePicker());
			this->BottomTitle = (gcnew System::Windows::Forms::Label());
			this->ModelDrop = (gcnew System::Windows::Forms::ComboBox());
			this->tableLayoutPanel4 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->SearchFilterDrop = (gcnew System::Windows::Forms::ComboBox());
			this->clearSearchButton = (gcnew System::Windows::Forms::Button());
			this->SearchButton = (gcnew System::Windows::Forms::Button());
			this->refreshUIButton = (gcnew System::Windows::Forms::Button());
			this->SearchBox = (gcnew System::Windows::Forms::TextBox());
			this->commentsTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->InventoryListView = (gcnew System::Windows::Forms::DataGridView());
			this->SNColumn = (gcnew System::Windows::Forms::DataGridViewButtonColumn());
			this->InvTagColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->BrandColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->ModelColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->NameColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->StatusColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->UserColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->DepartmentColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->LocationColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->TypeColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->DOPColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->DoLPIColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->DateUpdatedColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->UpdateNum = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->FileMenubutton = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fileSettingsMenu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->listSettingMenuButton = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->preferencesSettingMenuButton = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->checksSettingMenuButton = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fileSaveMenu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->termsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->supportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->bottomLeftStatus = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->tableLayoutPanel6 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->tableLayoutPanel1->SuspendLayout();
			this->tableLayoutPanel2->SuspendLayout();
			this->tableLayoutPanel3->SuspendLayout();
			this->tableLayoutPanel4->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->InventoryListView))->BeginInit();
			this->menuStrip1->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->tableLayoutPanel6->SuspendLayout();
			this->SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 2;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				450)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				100)));
			this->tableLayoutPanel1->Controls->Add(this->tableLayoutPanel2, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->InventoryListView, 1, 0);
			this->tableLayoutPanel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel1->Location = System::Drawing::Point(3, 28);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 1;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 100)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(1424, 787);
			this->tableLayoutPanel1->TabIndex = 0;
			// 
			// tableLayoutPanel2
			// 
			this->tableLayoutPanel2->ColumnCount = 1;
			this->tableLayoutPanel2->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				100)));
			this->tableLayoutPanel2->Controls->Add(this->tableLayoutPanel3, 0, 1);
			this->tableLayoutPanel2->Controls->Add(this->tableLayoutPanel4, 0, 0);
			this->tableLayoutPanel2->Controls->Add(this->commentsTextBox, 0, 3);
			this->tableLayoutPanel2->Controls->Add(this->label12, 0, 2);
			this->tableLayoutPanel2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel2->Location = System::Drawing::Point(3, 3);
			this->tableLayoutPanel2->Name = L"tableLayoutPanel2";
			this->tableLayoutPanel2->RowCount = 4;
			this->tableLayoutPanel2->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 250)));
			this->tableLayoutPanel2->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 300)));
			this->tableLayoutPanel2->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 35)));
			this->tableLayoutPanel2->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 100)));
			this->tableLayoutPanel2->Size = System::Drawing::Size(444, 781);
			this->tableLayoutPanel2->TabIndex = 1;
			// 
			// tableLayoutPanel3
			// 
			this->tableLayoutPanel3->AutoSize = true;
			this->tableLayoutPanel3->AutoSizeMode = System::Windows::Forms::AutoSizeMode::GrowAndShrink;
			this->tableLayoutPanel3->ColumnCount = 4;
			this->tableLayoutPanel3->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				25)));
			this->tableLayoutPanel3->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				25)));
			this->tableLayoutPanel3->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				25)));
			this->tableLayoutPanel3->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				25)));
			this->tableLayoutPanel3->Controls->Add(this->LPIDatePicker, 3, 6);
			this->tableLayoutPanel3->Controls->Add(this->DeptDrop, 3, 4);
			this->tableLayoutPanel3->Controls->Add(this->LocDrop, 3, 3);
			this->tableLayoutPanel3->Controls->Add(this->UserDrop, 3, 2);
			this->tableLayoutPanel3->Controls->Add(this->StatusDrop, 3, 1);
			this->tableLayoutPanel3->Controls->Add(this->BrandDrop, 1, 5);
			this->tableLayoutPanel3->Controls->Add(this->InvTagBox, 1, 1);
			this->tableLayoutPanel3->Controls->Add(this->label1, 0, 1);
			this->tableLayoutPanel3->Controls->Add(this->SNText, 0, 2);
			this->tableLayoutPanel3->Controls->Add(this->label7, 0, 3);
			this->tableLayoutPanel3->Controls->Add(this->label5, 2, 4);
			this->tableLayoutPanel3->Controls->Add(this->label3, 2, 3);
			this->tableLayoutPanel3->Controls->Add(this->label6, 2, 2);
			this->tableLayoutPanel3->Controls->Add(this->label8, 2, 1);
			this->tableLayoutPanel3->Controls->Add(this->label4, 0, 6);
			this->tableLayoutPanel3->Controls->Add(this->label9, 0, 5);
			this->tableLayoutPanel3->Controls->Add(this->label10, 0, 4);
			this->tableLayoutPanel3->Controls->Add(this->NameBox, 1, 3);
			this->tableLayoutPanel3->Controls->Add(this->SNBox, 1, 2);
			this->tableLayoutPanel3->Controls->Add(this->TypeDrop, 1, 6);
			this->tableLayoutPanel3->Controls->Add(this->SaveButton, 2, 8);
			this->tableLayoutPanel3->Controls->Add(this->ClearButton, 3, 8);
			this->tableLayoutPanel3->Controls->Add(this->label2, 2, 5);
			this->tableLayoutPanel3->Controls->Add(this->label11, 2, 6);
			this->tableLayoutPanel3->Controls->Add(this->DOPDatePicker, 3, 5);
			this->tableLayoutPanel3->Controls->Add(this->BottomTitle, 1, 0);
			this->tableLayoutPanel3->Controls->Add(this->ModelDrop, 1, 4);
			this->tableLayoutPanel3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel3->Location = System::Drawing::Point(3, 253);
			this->tableLayoutPanel3->Name = L"tableLayoutPanel3";
			this->tableLayoutPanel3->RowCount = 10;
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 30)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 35)));
			this->tableLayoutPanel3->RowStyles->Add((gcnew System::Windows::Forms::RowStyle()));
			this->tableLayoutPanel3->Size = System::Drawing::Size(438, 294);
			this->tableLayoutPanel3->TabIndex = 0;
			// 
			// LPIDatePicker
			// 
			this->LPIDatePicker->CustomFormat = L"MM.dd.yyyy";
			this->LPIDatePicker->Dock = System::Windows::Forms::DockStyle::Fill;
			this->LPIDatePicker->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->LPIDatePicker->Location = System::Drawing::Point(332, 185);
			this->LPIDatePicker->Margin = System::Windows::Forms::Padding(5);
			this->LPIDatePicker->Name = L"LPIDatePicker";
			this->LPIDatePicker->Size = System::Drawing::Size(101, 20);
			this->LPIDatePicker->TabIndex = 30;
			// 
			// DeptDrop
			// 
			this->DeptDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->DeptDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->DeptDrop->FormattingEnabled = true;
			this->DeptDrop->Location = System::Drawing::Point(332, 125);
			this->DeptDrop->Margin = System::Windows::Forms::Padding(5);
			this->DeptDrop->Name = L"DeptDrop";
			this->DeptDrop->Size = System::Drawing::Size(101, 21);
			this->DeptDrop->Sorted = true;
			this->DeptDrop->TabIndex = 24;
			// 
			// LocDrop
			// 
			this->LocDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->LocDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->LocDrop->FormattingEnabled = true;
			this->LocDrop->Location = System::Drawing::Point(332, 95);
			this->LocDrop->Margin = System::Windows::Forms::Padding(5);
			this->LocDrop->Name = L"LocDrop";
			this->LocDrop->Size = System::Drawing::Size(101, 21);
			this->LocDrop->Sorted = true;
			this->LocDrop->TabIndex = 23;
			// 
			// UserDrop
			// 
			this->UserDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->UserDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->UserDrop->FormattingEnabled = true;
			this->UserDrop->Location = System::Drawing::Point(332, 65);
			this->UserDrop->Margin = System::Windows::Forms::Padding(5);
			this->UserDrop->Name = L"UserDrop";
			this->UserDrop->Size = System::Drawing::Size(101, 21);
			this->UserDrop->Sorted = true;
			this->UserDrop->TabIndex = 22;
			// 
			// StatusDrop
			// 
			this->StatusDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->StatusDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->StatusDrop->FormattingEnabled = true;
			this->StatusDrop->Location = System::Drawing::Point(332, 35);
			this->StatusDrop->Margin = System::Windows::Forms::Padding(5);
			this->StatusDrop->Name = L"StatusDrop";
			this->StatusDrop->Size = System::Drawing::Size(101, 21);
			this->StatusDrop->TabIndex = 21;
			// 
			// BrandDrop
			// 
			this->BrandDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->BrandDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BrandDrop->FormattingEnabled = true;
			this->BrandDrop->Location = System::Drawing::Point(114, 155);
			this->BrandDrop->Margin = System::Windows::Forms::Padding(5);
			this->BrandDrop->Name = L"BrandDrop";
			this->BrandDrop->Size = System::Drawing::Size(99, 21);
			this->BrandDrop->Sorted = true;
			this->BrandDrop->TabIndex = 19;
			// 
			// InvTagBox
			// 
			this->InvTagBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->InvTagBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->InvTagBox->Location = System::Drawing::Point(114, 35);
			this->InvTagBox->Margin = System::Windows::Forms::Padding(5);
			this->InvTagBox->Name = L"InvTagBox";
			this->InvTagBox->Size = System::Drawing::Size(99, 20);
			this->InvTagBox->TabIndex = 12;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(5, 35);
			this->label1->Margin = System::Windows::Forms::Padding(5);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(99, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Inventory Tag";
			this->label1->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// SNText
			// 
			this->SNText->AutoSize = true;
			this->SNText->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SNText->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SNText->Location = System::Drawing::Point(5, 65);
			this->SNText->Margin = System::Windows::Forms::Padding(5);
			this->SNText->Name = L"SNText";
			this->SNText->Size = System::Drawing::Size(99, 20);
			this->SNText->TabIndex = 1;
			this->SNText->Text = L"S/N";
			this->SNText->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(5, 95);
			this->label7->Margin = System::Windows::Forms::Padding(5);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(99, 20);
			this->label7->TabIndex = 6;
			this->label7->Text = L"Name";
			this->label7->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(223, 125);
			this->label5->Margin = System::Windows::Forms::Padding(5);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(99, 20);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Dept";
			this->label5->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(223, 95);
			this->label3->Margin = System::Windows::Forms::Padding(5);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(99, 20);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Location";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(223, 65);
			this->label6->Margin = System::Windows::Forms::Padding(5);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(99, 20);
			this->label6->TabIndex = 5;
			this->label6->Text = L"User";
			this->label6->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(223, 35);
			this->label8->Margin = System::Windows::Forms::Padding(5);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(99, 20);
			this->label8->TabIndex = 7;
			this->label8->Text = L"Status";
			this->label8->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(5, 185);
			this->label4->Margin = System::Windows::Forms::Padding(5);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(99, 20);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Type";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(5, 155);
			this->label9->Margin = System::Windows::Forms::Padding(5);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(99, 20);
			this->label9->TabIndex = 8;
			this->label9->Text = L"Brand";
			this->label9->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(5, 125);
			this->label10->Margin = System::Windows::Forms::Padding(5);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(99, 20);
			this->label10->TabIndex = 9;
			this->label10->Text = L"Model";
			this->label10->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// NameBox
			// 
			this->NameBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->NameBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NameBox->Location = System::Drawing::Point(114, 95);
			this->NameBox->Margin = System::Windows::Forms::Padding(5);
			this->NameBox->Name = L"NameBox";
			this->NameBox->Size = System::Drawing::Size(99, 20);
			this->NameBox->TabIndex = 10;
			// 
			// SNBox
			// 
			this->SNBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SNBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SNBox->Location = System::Drawing::Point(114, 65);
			this->SNBox->Margin = System::Windows::Forms::Padding(5);
			this->SNBox->Name = L"SNBox";
			this->SNBox->Size = System::Drawing::Size(99, 20);
			this->SNBox->TabIndex = 11;
			// 
			// TypeDrop
			// 
			this->TypeDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->TypeDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TypeDrop->FormattingEnabled = true;
			this->TypeDrop->Location = System::Drawing::Point(114, 185);
			this->TypeDrop->Margin = System::Windows::Forms::Padding(5);
			this->TypeDrop->Name = L"TypeDrop";
			this->TypeDrop->Size = System::Drawing::Size(99, 21);
			this->TypeDrop->Sorted = true;
			this->TypeDrop->TabIndex = 20;
			// 
			// SaveButton
			// 
			this->SaveButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SaveButton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SaveButton->Location = System::Drawing::Point(223, 245);
			this->SaveButton->Margin = System::Windows::Forms::Padding(5);
			this->SaveButton->Name = L"SaveButton";
			this->SaveButton->Size = System::Drawing::Size(99, 25);
			this->SaveButton->TabIndex = 25;
			this->SaveButton->Text = L"Save";
			this->SaveButton->UseVisualStyleBackColor = true;
			this->SaveButton->Click += gcnew System::EventHandler(this, &MyForm::SaveButton_Click);
			// 
			// ClearButton
			// 
			this->ClearButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->ClearButton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClearButton->Location = System::Drawing::Point(332, 245);
			this->ClearButton->Margin = System::Windows::Forms::Padding(5);
			this->ClearButton->Name = L"ClearButton";
			this->ClearButton->Size = System::Drawing::Size(101, 25);
			this->ClearButton->TabIndex = 26;
			this->ClearButton->Text = L"Clear";
			this->ClearButton->UseVisualStyleBackColor = true;
			this->ClearButton->Click += gcnew System::EventHandler(this, &MyForm::ClearButton_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(223, 155);
			this->label2->Margin = System::Windows::Forms::Padding(5);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(99, 20);
			this->label2->TabIndex = 27;
			this->label2->Text = L"Date of Purchase";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(223, 185);
			this->label11->Margin = System::Windows::Forms::Padding(5);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(99, 20);
			this->label11->TabIndex = 28;
			this->label11->Text = L"Date of LPI";
			this->label11->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// DOPDatePicker
			// 
			this->DOPDatePicker->CustomFormat = L"MM.dd.yyyy";
			this->DOPDatePicker->Dock = System::Windows::Forms::DockStyle::Fill;
			this->DOPDatePicker->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->DOPDatePicker->Location = System::Drawing::Point(332, 155);
			this->DOPDatePicker->Margin = System::Windows::Forms::Padding(5);
			this->DOPDatePicker->Name = L"DOPDatePicker";
			this->DOPDatePicker->Size = System::Drawing::Size(101, 20);
			this->DOPDatePicker->TabIndex = 29;
			// 
			// BottomTitle
			// 
			this->BottomTitle->AutoSize = true;
			this->tableLayoutPanel3->SetColumnSpan(this->BottomTitle, 2);
			this->BottomTitle->Dock = System::Windows::Forms::DockStyle::Fill;
			this->BottomTitle->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BottomTitle->Location = System::Drawing::Point(114, 5);
			this->BottomTitle->Margin = System::Windows::Forms::Padding(5);
			this->BottomTitle->Name = L"BottomTitle";
			this->BottomTitle->Size = System::Drawing::Size(208, 20);
			this->BottomTitle->TabIndex = 31;
			this->BottomTitle->Text = L"Edit";
			this->BottomTitle->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// ModelDrop
			// 
			this->ModelDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->ModelDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ModelDrop->FormattingEnabled = true;
			this->ModelDrop->Location = System::Drawing::Point(114, 125);
			this->ModelDrop->Margin = System::Windows::Forms::Padding(5);
			this->ModelDrop->Name = L"ModelDrop";
			this->ModelDrop->Size = System::Drawing::Size(99, 21);
			this->ModelDrop->Sorted = true;
			this->ModelDrop->TabIndex = 32;
			// 
			// tableLayoutPanel4
			// 
			this->tableLayoutPanel4->AutoSizeMode = System::Windows::Forms::AutoSizeMode::GrowAndShrink;
			this->tableLayoutPanel4->ColumnCount = 5;
			this->tableLayoutPanel4->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50)));
			this->tableLayoutPanel4->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				125)));
			this->tableLayoutPanel4->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				125)));
			this->tableLayoutPanel4->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				125)));
			this->tableLayoutPanel4->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50)));
			this->tableLayoutPanel4->Controls->Add(this->SearchFilterDrop, 1, 1);
			this->tableLayoutPanel4->Controls->Add(this->clearSearchButton, 1, 2);
			this->tableLayoutPanel4->Controls->Add(this->SearchButton, 3, 2);
			this->tableLayoutPanel4->Controls->Add(this->refreshUIButton, 1, 3);
			this->tableLayoutPanel4->Controls->Add(this->SearchBox, 2, 1);
			this->tableLayoutPanel4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel4->Location = System::Drawing::Point(3, 3);
			this->tableLayoutPanel4->Name = L"tableLayoutPanel4";
			this->tableLayoutPanel4->RowCount = 6;
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 20)));
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 35)));
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 35)));
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 35)));
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 100)));
			this->tableLayoutPanel4->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 20)));
			this->tableLayoutPanel4->Size = System::Drawing::Size(438, 244);
			this->tableLayoutPanel4->TabIndex = 1;
			// 
			// SearchFilterDrop
			// 
			this->SearchFilterDrop->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SearchFilterDrop->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->SearchFilterDrop->FormattingEnabled = true;
			this->SearchFilterDrop->Items->AddRange(gcnew cli::array< System::Object^  >(14) {
				L"Serial Number", L"Inventory Tag", L"Brand",
					L"Model", L"Name", L"Status", L"User", L"Department", L"Location", L"Type", L"Date of Purchase", L"DoLPI", L"Date Updated", L"Update"
			});
			this->SearchFilterDrop->Location = System::Drawing::Point(37, 26);
			this->SearchFilterDrop->Margin = System::Windows::Forms::Padding(6);
			this->SearchFilterDrop->Name = L"SearchFilterDrop";
			this->SearchFilterDrop->Size = System::Drawing::Size(113, 21);
			this->SearchFilterDrop->TabIndex = 0;
			this->SearchFilterDrop->Text = L"Search By";
			// 
			// clearSearchButton
			// 
			this->clearSearchButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->clearSearchButton->Location = System::Drawing::Point(36, 60);
			this->clearSearchButton->Margin = System::Windows::Forms::Padding(5);
			this->clearSearchButton->Name = L"clearSearchButton";
			this->clearSearchButton->Size = System::Drawing::Size(115, 25);
			this->clearSearchButton->TabIndex = 1;
			this->clearSearchButton->Text = L"Clear Search";
			this->clearSearchButton->UseVisualStyleBackColor = true;
			this->clearSearchButton->Click += gcnew System::EventHandler(this, &MyForm::clearSearchButton_Click);
			// 
			// SearchButton
			// 
			this->SearchButton->Dock = System::Windows::Forms::DockStyle::Right;
			this->SearchButton->Location = System::Drawing::Point(286, 60);
			this->SearchButton->Margin = System::Windows::Forms::Padding(5);
			this->SearchButton->Name = L"SearchButton";
			this->SearchButton->Size = System::Drawing::Size(115, 25);
			this->SearchButton->TabIndex = 3;
			this->SearchButton->Text = L"Search";
			this->SearchButton->UseVisualStyleBackColor = true;
			this->SearchButton->Click += gcnew System::EventHandler(this, &MyForm::SearchButton_Click);
			// 
			// refreshUIButton
			// 
			this->refreshUIButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->refreshUIButton->Location = System::Drawing::Point(36, 95);
			this->refreshUIButton->Margin = System::Windows::Forms::Padding(5);
			this->refreshUIButton->Name = L"refreshUIButton";
			this->refreshUIButton->Size = System::Drawing::Size(115, 25);
			this->refreshUIButton->TabIndex = 4;
			this->refreshUIButton->Text = L"Refresh UI";
			this->refreshUIButton->UseVisualStyleBackColor = true;
			this->refreshUIButton->Click += gcnew System::EventHandler(this, &MyForm::refreshUIButton_Click);
			// 
			// SearchBox
			// 
			this->tableLayoutPanel4->SetColumnSpan(this->SearchBox, 2);
			this->SearchBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SearchBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SearchBox->Location = System::Drawing::Point(162, 26);
			this->SearchBox->Margin = System::Windows::Forms::Padding(6);
			this->SearchBox->Name = L"SearchBox";
			this->SearchBox->Size = System::Drawing::Size(238, 21);
			this->SearchBox->TabIndex = 2;
			// 
			// commentsTextBox
			// 
			this->commentsTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->commentsTextBox->Location = System::Drawing::Point(3, 588);
			this->commentsTextBox->Name = L"commentsTextBox";
			this->commentsTextBox->Size = System::Drawing::Size(438, 190);
			this->commentsTextBox->TabIndex = 2;
			this->commentsTextBox->Text = L"";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Dock = System::Windows::Forms::DockStyle::Fill;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->Location = System::Drawing::Point(3, 550);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(438, 35);
			this->label12->TabIndex = 3;
			this->label12->Text = L"Comments";
			this->label12->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// InventoryListView
			// 
			this->InventoryListView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->InventoryListView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(14) {
				this->SNColumn,
					this->InvTagColumn, this->BrandColumn, this->ModelColumn, this->NameColumn, this->StatusColumn, this->UserColumn, this->DepartmentColumn,
					this->LocationColumn, this->TypeColumn, this->DOPColumn, this->DoLPIColumn, this->DateUpdatedColumn, this->UpdateNum
			});
			this->InventoryListView->Dock = System::Windows::Forms::DockStyle::Fill;
			this->InventoryListView->Location = System::Drawing::Point(453, 3);
			this->InventoryListView->Name = L"InventoryListView";
			this->InventoryListView->Size = System::Drawing::Size(968, 781);
			this->InventoryListView->TabIndex = 0;
			this->InventoryListView->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MyForm::InventoryListView_CellContentClick);
			// 
			// SNColumn
			// 
			this->SNColumn->HeaderText = L"S/N";
			this->SNColumn->Name = L"SNColumn";
			this->SNColumn->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::Automatic;
			// 
			// InvTagColumn
			// 
			this->InvTagColumn->HeaderText = L"Inv Tag";
			this->InvTagColumn->Name = L"InvTagColumn";
			// 
			// BrandColumn
			// 
			this->BrandColumn->HeaderText = L"Brand";
			this->BrandColumn->Name = L"BrandColumn";
			// 
			// ModelColumn
			// 
			this->ModelColumn->HeaderText = L"Model";
			this->ModelColumn->Name = L"ModelColumn";
			// 
			// NameColumn
			// 
			this->NameColumn->HeaderText = L"Name";
			this->NameColumn->Name = L"NameColumn";
			// 
			// StatusColumn
			// 
			this->StatusColumn->HeaderText = L"Status";
			this->StatusColumn->Name = L"StatusColumn";
			// 
			// UserColumn
			// 
			this->UserColumn->HeaderText = L"User";
			this->UserColumn->Name = L"UserColumn";
			// 
			// DepartmentColumn
			// 
			this->DepartmentColumn->HeaderText = L"Department";
			this->DepartmentColumn->Name = L"DepartmentColumn";
			// 
			// LocationColumn
			// 
			this->LocationColumn->HeaderText = L"Location";
			this->LocationColumn->Name = L"LocationColumn";
			// 
			// TypeColumn
			// 
			this->TypeColumn->HeaderText = L"Type";
			this->TypeColumn->Name = L"TypeColumn";
			// 
			// DOPColumn
			// 
			this->DOPColumn->HeaderText = L"DOP";
			this->DOPColumn->Name = L"DOPColumn";
			// 
			// DoLPIColumn
			// 
			this->DoLPIColumn->HeaderText = L"DoLPI";
			this->DoLPIColumn->Name = L"DoLPIColumn";
			// 
			// DateUpdatedColumn
			// 
			this->DateUpdatedColumn->HeaderText = L"DateUpdated";
			this->DateUpdatedColumn->Name = L"DateUpdatedColumn";
			// 
			// UpdateNum
			// 
			this->UpdateNum->HeaderText = L"Update";
			this->UpdateNum->Name = L"UpdateNum";
			this->UpdateNum->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::Programmatic;
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) { this->FileMenubutton, this->helpToolStripMenuItem });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1430, 24);
			this->menuStrip1->TabIndex = 3;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// FileMenubutton
			// 
			this->FileMenubutton->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->fileSettingsMenu,
					this->fileSaveMenu
			});
			this->FileMenubutton->Name = L"FileMenubutton";
			this->FileMenubutton->Size = System::Drawing::Size(37, 20);
			this->FileMenubutton->Text = L"File";
			// 
			// fileSettingsMenu
			// 
			this->fileSettingsMenu->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->listSettingMenuButton,
					this->preferencesSettingMenuButton, this->checksSettingMenuButton
			});
			this->fileSettingsMenu->Name = L"fileSettingsMenu";
			this->fileSettingsMenu->Size = System::Drawing::Size(116, 22);
			this->fileSettingsMenu->Text = L"Settings";
			this->fileSettingsMenu->Click += gcnew System::EventHandler(this, &MyForm::fileSettingsMenu_Click);
			// 
			// listSettingMenuButton
			// 
			this->listSettingMenuButton->Name = L"listSettingMenuButton";
			this->listSettingMenuButton->Size = System::Drawing::Size(135, 22);
			this->listSettingMenuButton->Text = L"Lists";
			this->listSettingMenuButton->Click += gcnew System::EventHandler(this, &MyForm::listSettingMenuButton_Click);
			// 
			// preferencesSettingMenuButton
			// 
			this->preferencesSettingMenuButton->Name = L"preferencesSettingMenuButton";
			this->preferencesSettingMenuButton->Size = System::Drawing::Size(135, 22);
			this->preferencesSettingMenuButton->Text = L"Preferences";
			// 
			// checksSettingMenuButton
			// 
			this->checksSettingMenuButton->Name = L"checksSettingMenuButton";
			this->checksSettingMenuButton->Size = System::Drawing::Size(135, 22);
			this->checksSettingMenuButton->Text = L"Checks";
			// 
			// fileSaveMenu
			// 
			this->fileSaveMenu->Name = L"fileSaveMenu";
			this->fileSaveMenu->Size = System::Drawing::Size(116, 22);
			this->fileSaveMenu->Text = L"Save";
			// 
			// helpToolStripMenuItem
			// 
			this->helpToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->termsToolStripMenuItem,
					this->aboutToolStripMenuItem, this->supportToolStripMenuItem
			});
			this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
			this->helpToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->helpToolStripMenuItem->Text = L"Help";
			// 
			// termsToolStripMenuItem
			// 
			this->termsToolStripMenuItem->Name = L"termsToolStripMenuItem";
			this->termsToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->termsToolStripMenuItem->Text = L"Terms";
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->aboutToolStripMenuItem->Text = L"About";
			// 
			// supportToolStripMenuItem
			// 
			this->supportToolStripMenuItem->Name = L"supportToolStripMenuItem";
			this->supportToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->supportToolStripMenuItem->Text = L"Support";
			// 
			// bottomLeftStatus
			// 
			this->bottomLeftStatus->Name = L"bottomLeftStatus";
			this->bottomLeftStatus->Size = System::Drawing::Size(39, 17);
			this->bottomLeftStatus->Text = L"Ready";
			// 
			// statusStrip1
			// 
			this->statusStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->bottomLeftStatus });
			this->statusStrip1->Location = System::Drawing::Point(0, 821);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(1430, 22);
			this->statusStrip1->TabIndex = 4;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// tableLayoutPanel6
			// 
			this->tableLayoutPanel6->ColumnCount = 1;
			this->tableLayoutPanel6->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				100)));
			this->tableLayoutPanel6->Controls->Add(this->statusStrip1, 0, 2);
			this->tableLayoutPanel6->Controls->Add(this->tableLayoutPanel1, 0, 1);
			this->tableLayoutPanel6->Controls->Add(this->menuStrip1, 0, 0);
			this->tableLayoutPanel6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel6->Location = System::Drawing::Point(0, 0);
			this->tableLayoutPanel6->Name = L"tableLayoutPanel6";
			this->tableLayoutPanel6->RowCount = 3;
			this->tableLayoutPanel6->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 25)));
			this->tableLayoutPanel6->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 100)));
			this->tableLayoutPanel6->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 25)));
			this->tableLayoutPanel6->Size = System::Drawing::Size(1430, 843);
			this->tableLayoutPanel6->TabIndex = 5;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1430, 843);
			this->Controls->Add(this->tableLayoutPanel6);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"MyForm";
			this->Text = L"Inventory";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->tableLayoutPanel1->ResumeLayout(false);
			this->tableLayoutPanel2->ResumeLayout(false);
			this->tableLayoutPanel2->PerformLayout();
			this->tableLayoutPanel3->ResumeLayout(false);
			this->tableLayoutPanel3->PerformLayout();
			this->tableLayoutPanel4->ResumeLayout(false);
			this->tableLayoutPanel4->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->InventoryListView))->EndInit();
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->tableLayoutPanel6->ResumeLayout(false);
			this->tableLayoutPanel6->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		//Get list from textFile
		updateList(BrandDrop);
		updateList(DeptDrop);
		updateList(TypeDrop);
		updateList(StatusDrop);
		updateList(LocDrop);
		updateList(UserDrop);
		updateList(ModelDrop);
		InventoryListView->Rows->Clear();
		reUpdateTable();
	}
public: System::String^ getTodaysDate() {
	DateTime dTime = DateTime::Today;
	String ^ nMonth = dTime.Month.ToString();
	String ^ nDay = dTime.Day.ToString();
	String ^ nYear = dTime.Year.ToString();
	String ^ nDate = nMonth + "." + nDay + "." + nYear;
	return nDate;
}
public: System::Void reUpdateTable() {
	int rowCnt = 0;
	//wipe table and get new?
	InventoryListView->Rows->Clear();
	String ^ fileName = "data/main/main.txt";
	if (!File::Exists(fileName)) {
		Console::WriteLine("{0} does not exist.", fileName);
		return;
	}
	else {
		StreamReader^ sr = File::OpenText(fileName);
		String^ input;
		String ^ str;

		String ^ delimStr = ";;;";
		array<Char>^ delimiCar = delimStr->ToCharArray();
		array<String^>^ sepStr;

		//int t = 0;
		while ((input = sr->ReadLine()) != nullptr)
		{

			//Make it so there isn't a blank row in the table
			//if (t <= rowCnt) {
				//don't add more rows
			//}
			//else {
				sepStr = input->Split(delimiCar);
				if (!sepStr->Equals("")) {
					InventoryListView->Rows->Add(sepStr);
					
					rowCnt++;
				}
			//}
			//t++;
		}
		sr->Close();
		for (int q = 0; q < InventoryListView->RowCount; q++) {
			//InventoryListView->Rows[q]->Cells[13]->Value = System::Int32::Parse(sepStr[13]);
		}
	}
}

private: System::Void SaveButton_Click(System::Object^  sender, System::EventArgs^  e) {
	String ^ invTag = InvTagBox->Text;
	String ^ SNnumber = SNBox->Text;
	String ^ ModelN = ModelDrop->Text;
	String ^ MachineName = NameBox->Text;
	String ^ BrandD = BrandDrop->Text;
	String ^ TypeD = TypeDrop->Text;
	String ^ StatusD = StatusDrop->Text;
	String ^ LocationD = LocDrop->Text;
	String ^ UserD = UserDrop->Text;
	String ^ DepartmentD = DeptDrop->Text;
	String ^ DOPd = DOPDatePicker->Text;
	String ^ DoLPI = LPIDatePicker->Text;
	String ^ Comm = commentsTextBox->Text;
	String ^ TodayDate = getTodaysDate();
	searchGrid(SNnumber, 0);
	custSortAll(13);
	InventoryListView->Sort(this->InventoryListView->Columns[13], System::ComponentModel::ListSortDirection::Descending);
	String ^ tempUpNum;
	double updateNum;
	///if (InventoryListView->Rows[0]->Cells[13]->Value == NULL) {
		//tempUpNum = InventoryListView->Rows[0]->Cells[13]->Value->ToString();
		//int updateNum = System::Convert::ToInt32(tempUpNum);
		//updateNum = 0;
	///}
	//else {
		//updateNum = 0;
		//tempUpNum = InventoryListView->Rows[0]->Cells[13]->Value->ToString();
		///updateNum = System::Int32::Parse(tempUpNum);
	//}
	//updateNum = updateNum + 1;

	String ^ line = SNnumber + ";" + invTag + ";" + BrandD + ";" + ModelN + ";" + MachineName + ";" + StatusD + ";" + UserD + ";" + DepartmentD + ";" + LocationD + ";"  + TypeD + ";" + DOPd + ";" + DoLPI + ";" + TodayDate + ";" + updateNum;
	//InventoryListView->
	//if main.txt doesn't exist
	String ^ fileName = "data/main/main.txt";
	if (!File::Exists(fileName)) {
		StreamWriter^ sw = gcnew StreamWriter(fileName);
		sw->Close();
		return;
	}
	StreamReader^ sr = File::OpenText(fileName);
	String^ fileD;
	String ^ totalStr;
	while ((fileD = sr->ReadLine()) != nullptr)
	{
		if (!sr->EndOfStream) {
			totalStr = fileD + "\n" + totalStr;
		}
		else if (sr->EndOfStream) {
			totalStr = totalStr + fileD;
		}
	}
	sr->Close();
	
	String ^ newLn;
	StreamWriter^ sw = gcnew StreamWriter(fileName);
	if (String::IsNullOrEmpty(totalStr)) {
		sw->WriteLine(line);
	}
	else {
		sw->WriteLine(totalStr + "\n" + line);
	}		
	sw->Close();

	String ^ cmFileName = "data/comments/" + SNnumber + ".txt";
	String ^ totalStr1;
	String ^ newLn1;
	StreamWriter^ sw1 = gcnew StreamWriter(cmFileName);
	sw1->WriteLine(Comm);
	sw1->Close();

	reUpdateTable();
}
private: System::Void ClearButton_Click(System::Object^  sender, System::EventArgs^  e) {
	clearFields();
}

public: System::Void custSortAll(int columnToSort) {
	for (int i = 0; i < InventoryListView->RowCount; i++) {
		//Convert::ToInt32(InventoryListView->Rows[0]->Cells[13]->Value);
	}
	//InventoryListView->Rows[0]->Cells[13]->Value->ToString();
}


private: System::Void clearSearchButton_Click(System::Object^  sender, System::EventArgs^  e) {
	SearchBox->Text = "";
}

public: System::Void setBottomStatusMsg(String ^ msg) {
	bottomLeftStatus->Text = msg;
}
private: System::Void fileSettingsMenu_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void SearchButton_Click(System::Object^  sender, System::EventArgs^  e) {
	reUpdateTable();
	int searchB = 0;
	String ^ searchT = SearchBox->Text;
	if (SearchFilterDrop->Text == "Serial Number") { searchB = 0; }
	else if (SearchFilterDrop->Text == "Inventory Tag") { searchB = 1; }
	if (SearchFilterDrop->Text == "Brand") { searchB = 2; }
	if (SearchFilterDrop->Text == "Model") { searchB = 3; }
	if (SearchFilterDrop->Text == "Name") { searchB = 4; }
	if (SearchFilterDrop->Text == "Status") { searchB = 5; }
	if (SearchFilterDrop->Text == "User") { searchB = 6; }
	if (SearchFilterDrop->Text == "Department") { searchB = 7; }
	if (SearchFilterDrop->Text == "Location") { searchB = 8; }
	if (SearchFilterDrop->Text == "Type") { searchB = 9; }
	if (SearchFilterDrop->Text == "Date of Purchase") { searchB = 10; }
	if (SearchFilterDrop->Text == "DoLPI") { searchB = 11; }
	if (SearchFilterDrop->Text == "Date Updated") { searchB = 12; }
	if (SearchFilterDrop->Text == "Update") { searchB = 13; }
	searchGrid(searchT, searchB);
}

private: System::Void listSettingMenuButton_Click(System::Object^  sender, System::EventArgs^  e) {
	ListForm ^ listsF = gcnew ListForm;
	listsF->ShowDialog();
}

public: System::Void clearFields() {
	InvTagBox->Text = "";
	SNBox->Text = "";
	ModelDrop->Text = "";
	NameBox->Text = "";
	BrandDrop->Text = "";
	TypeDrop->Text = "";
	StatusDrop->Text = "";
	LocDrop->Text = "";
	UserDrop->Text = "";
	DeptDrop->Text = "";
	DOPDatePicker->Text = "";
	LPIDatePicker->Text = "";
	commentsTextBox->Text = "";
}

public: System::Void updateList(System::Windows::Forms::ComboBox ^ dropBo) {
	dropBo->Items->Clear(); //reset content

	String^ fileName;
	if (dropBo->Name == L"BrandDrop") {
		fileName = "data/lists/brandList.txt";
	}
	else if (dropBo->Name == L"DeptDrop") {
		fileName = "data/lists/deptList.txt";
	}
	else if (dropBo->Name == L"TypeDrop") {
		fileName = "data/lists/typeList.txt";
	}
	else if (dropBo->Name == L"StatusDrop") {
		fileName = "data/lists/statusList.txt";
	}
	else if (dropBo->Name == L"LocDrop") {
		fileName = "data/lists/locationList.txt";
	}
	else if (dropBo->Name == L"UserDrop") {
		fileName = "data/lists/userList.txt";
	}
	else if (dropBo->Name == L"ModelDrop") {
		fileName = "data/lists/modelList.txt";
	}


	if (!File::Exists(fileName)) {
		return;
	}
	StreamReader^ sr = File::OpenText(fileName);
	String^ input;
	while ((input = sr->ReadLine()) != nullptr)
	{
		Console::WriteLine(input);
		dropBo->Items->Add(input);
	}
	sr->Close();
}


private: System::Void InventoryListView_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
	if (InventoryListView->Columns[e->ColumnIndex]->Name == "SNColumn") {
		//InventoryListView->Sort(this->InventoryListView->Columns[13], System::ComponentModel::ListSortDirection::Descending);
		String ^ str = InventoryListView->CurrentRow->Cells->ToString();
		array<String^> ^ sepStr = str->Split();

		clearFields();

		InvTagBox->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+1]->Value->ToString();
		SNBox->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Value->ToString();
		ModelDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+3]->Value->ToString();
		NameBox->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+4]->Value->ToString();;
		BrandDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+2]->Value->ToString();;
		TypeDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+9]->Value->ToString();;
		StatusDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+5]->Value->ToString();;
		LocDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+8]->Value->ToString();;
		UserDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+6]->Value->ToString();;
		DeptDrop->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+7]->Value->ToString();;
		DOPDatePicker->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+10]->Value->ToString();;
		LPIDatePicker->Text = InventoryListView->Rows[e->RowIndex]->Cells[e->ColumnIndex+11]->Value->ToString();;
		
		String ^ snNum = SNBox->Text;
		String ^ cmFileName = "data/comments/" + snNum + ".txt";
		if (!File::Exists(cmFileName)) {
			//return;
		}
		StreamReader^ sr = File::OpenText(cmFileName);
		String^ input;
		String ^ str1;
		while ((input = sr->ReadLine()) != nullptr)
		{
			if (input == "") {
				//return;
			}
			else {
				if (!sr->EndOfStream) {
					str1 = input + "\n" + str1;
				}
				else if (sr->EndOfStream) {
					str1 = str1 + input;
				}
			}
		}
		sr->Close();
		commentsTextBox->Text = str1;
		searchGrid(snNum, 0);
		InventoryListView->Sort(this->InventoryListView->Columns[13], System::ComponentModel::ListSortDirection::Descending);
	}
	

}
public: System::Void refreshUIButton_Click(System::Object^  sender, System::EventArgs^  e) {
	reUpdateTable();
	updateList(BrandDrop);
	updateList(DeptDrop);
	updateList(TypeDrop);
	updateList(StatusDrop);
	updateList(LocDrop);
	updateList(UserDrop);
	updateList(ModelDrop);
	clearFields();
	SearchBox->Text = "";
	setBottomStatusMsg("Refreshed");
}


public: System::Void searchGrid(String ^ searchBoxText, int searchBy) {
	String ^ tempS;
	String ^ tS;
	String ^ fileName = "data/temp/temp.txt";
	String ^ totalStr;
	StreamWriter^ sw = gcnew StreamWriter(fileName);
	for (int i = 0; i < InventoryListView->Rows->Count - 1; i++) {

		String ^ fText = InventoryListView->Rows[i]->Cells[searchBy]->Value->ToString();
		if (fText == searchBoxText) {
			if (tempS == "") {
				for (int r = 0; r < 13; r++) {
					tempS = InventoryListView->Rows[i]->Cells[r]->Value->ToString() + ";";
				}
				tempS = InventoryListView->Rows[i]->Cells[13]->Value->ToString() + "\n";
			}
			else {
				for (int r = 0; r < 13; r++) {
					tempS = tempS + InventoryListView->Rows[i]->Cells[r]->Value->ToString() + ";";
					//commentsTextBox->Text = tempS;
				}
				tS = InventoryListView->Rows[i]->Cells[13]->Value->ToString();
				tempS = tempS + tS + "\n";
			}
		}
	}
	sw->WriteLine(tempS);
	sw->Close();


	InventoryListView->Rows->Clear();
	
	StreamReader^ sr = File::OpenText(fileName);
	String^ input;
	String ^ str;
	String ^ delimStr = ";;;";
	array<Char>^ delimiCar = delimStr->ToCharArray();
	array<String^>^ sepStr;

	int t = 0;
	while ((input = sr->ReadLine()) != nullptr)
	{
		//Make it so there isn't a blank row in the table
		if (input == "" || input == "\n") {
			//don't add more rows
		}
		else {
			sepStr = input->Split(delimiCar);
			if (!sepStr->Equals("")) {
				InventoryListView->Rows->Add(sepStr);
				rowCnt++;
			}
		}
	}
	sr->Close();
}

};

}
