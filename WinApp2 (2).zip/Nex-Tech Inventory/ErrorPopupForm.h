//#include "ConfirmationForm.h"
//#include "MainForm.h"
#include <Windows.h>

#pragma once

//#include "MainForm.h"



namespace WinApp2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for ErrorPopupForm
	/// </summary>
	public ref class ErrorPopupForm : public System::Windows::Forms::Form
	{
	public:
		
		
		
		ErrorPopupForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			//String ^ errorMessage = "";
		}
		/*void setMesText(String ^ message) {
			errorMessage = message;
		}*/


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ErrorPopupForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel1;
	public: System::Windows::Forms::Label^  ErrorTextLabel;
	private:
	protected:

	private: System::Windows::Forms::Button^  OKButton;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>

	public:
		void InitializeComponent(void)
		{
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->ErrorTextLabel = (gcnew System::Windows::Forms::Label());
			this->OKButton = (gcnew System::Windows::Forms::Button());
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 1;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50)));
			this->tableLayoutPanel1->Controls->Add(this->ErrorTextLabel, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->OKButton, 0, 1);
			this->tableLayoutPanel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel1->Location = System::Drawing::Point(0, 0);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 2;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 60.73298F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 39.26702F)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(548, 191);
			this->tableLayoutPanel1->TabIndex = 0;
			// 
			// ErrorTextLabel
			// 
			this->ErrorTextLabel->AutoSize = true;
			this->ErrorTextLabel->Dock = System::Windows::Forms::DockStyle::Fill;
			this->ErrorTextLabel->Location = System::Drawing::Point(3, 0);
			this->ErrorTextLabel->Name = L"ErrorTextLabel";
			this->ErrorTextLabel->Padding = System::Windows::Forms::Padding(5);
			this->ErrorTextLabel->Size = System::Drawing::Size(542, 115);
			this->ErrorTextLabel->TabIndex = 0;
			this->ErrorTextLabel->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// OKButton
			// 
			this->OKButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->OKButton->Location = System::Drawing::Point(200, 135);
			this->OKButton->Margin = System::Windows::Forms::Padding(200, 20, 200, 20);
			this->OKButton->Name = L"OKButton";
			this->OKButton->Size = System::Drawing::Size(148, 36);
			this->OKButton->TabIndex = 1;
			this->OKButton->Text = L"OK";
			this->OKButton->UseVisualStyleBackColor = true;
			this->OKButton->Click += gcnew System::EventHandler(this, &ErrorPopupForm::OKButton_Click);
			// 
			// ErrorPopupForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(548, 191);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Name = L"ErrorPopupForm";
			this->Text = L"ErrorPopupForm";
			this->Load += gcnew System::EventHandler(this, &ErrorPopupForm::ErrorPopupForm_Load);
			this->tableLayoutPanel1->ResumeLayout(false);
			this->tableLayoutPanel1->PerformLayout();
			this->ResumeLayout(false);

		}

#pragma endregion
	private: System::Void OKButton_Click(System::Object^  sender, System::EventArgs^  e) {

		Close();
	}
	public: System::Void errorPopMsg(String ^ message) {
		ErrorTextLabel->Text = message;
	}
		private: System::Void ErrorPopupForm_Load(System::Object^  sender, System::EventArgs^  e) {

	}


};

}
