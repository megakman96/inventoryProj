//#include <fstream>
#include <iostream>
//#include <String>
//using namespace std;
using namespace System;
using namespace System::IO;



#pragma once

namespace WinApp2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for ListForm
	/// </summary>
	public ref class ListForm : public System::Windows::Forms::Form
	{
	public:
		ListForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		//Array ^ brArry;

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ListForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  tabControl1;
	protected:
	private: System::Windows::Forms::TabPage^  BrandsTab;
	private: System::Windows::Forms::TabPage^  DepartmentsTab;
	private: System::Windows::Forms::TabPage^  LocationsTab;
	private: System::Windows::Forms::TabPage^  ModelsTab;
	private: System::Windows::Forms::TabPage^  StatusesTab;
	private: System::Windows::Forms::TabPage^  TypeTab;
	private: System::Windows::Forms::TabPage^  UsersTab;
	public: System::Windows::Forms::RichTextBox^  BrandsTextBox;
	private:

	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel1;
	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel2;
	private: System::Windows::Forms::Button^  SaveButton;
	private: System::Windows::Forms::Button^  CloseButton;
	public: System::Windows::Forms::RichTextBox^  DepartmentsTextBox;
	public: System::Windows::Forms::RichTextBox^  LocationsTextBox;
	public: System::Windows::Forms::RichTextBox^  ModelsTextBox;
	public: System::Windows::Forms::RichTextBox^  StatusTextBox;
	public: System::Windows::Forms::RichTextBox^  TypeTextBox;
	public: System::Windows::Forms::RichTextBox^  UserTextBox;
	private:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->BrandsTab = (gcnew System::Windows::Forms::TabPage());
			this->BrandsTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->DepartmentsTab = (gcnew System::Windows::Forms::TabPage());
			this->DepartmentsTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->LocationsTab = (gcnew System::Windows::Forms::TabPage());
			this->ModelsTab = (gcnew System::Windows::Forms::TabPage());
			this->StatusesTab = (gcnew System::Windows::Forms::TabPage());
			this->TypeTab = (gcnew System::Windows::Forms::TabPage());
			this->UsersTab = (gcnew System::Windows::Forms::TabPage());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->tableLayoutPanel2 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->SaveButton = (gcnew System::Windows::Forms::Button());
			this->CloseButton = (gcnew System::Windows::Forms::Button());
			this->LocationsTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->ModelsTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->StatusTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->TypeTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->UserTextBox = (gcnew System::Windows::Forms::RichTextBox());
			this->tabControl1->SuspendLayout();
			this->BrandsTab->SuspendLayout();
			this->DepartmentsTab->SuspendLayout();
			this->LocationsTab->SuspendLayout();
			this->ModelsTab->SuspendLayout();
			this->StatusesTab->SuspendLayout();
			this->TypeTab->SuspendLayout();
			this->UsersTab->SuspendLayout();
			this->tableLayoutPanel1->SuspendLayout();
			this->tableLayoutPanel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->BrandsTab);
			this->tabControl1->Controls->Add(this->DepartmentsTab);
			this->tabControl1->Controls->Add(this->LocationsTab);
			this->tabControl1->Controls->Add(this->ModelsTab);
			this->tabControl1->Controls->Add(this->StatusesTab);
			this->tabControl1->Controls->Add(this->TypeTab);
			this->tabControl1->Controls->Add(this->UsersTab);
			this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tabControl1->Location = System::Drawing::Point(3, 3);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(784, 421);
			this->tabControl1->TabIndex = 1;
			// 
			// BrandsTab
			// 
			this->BrandsTab->Controls->Add(this->BrandsTextBox);
			this->BrandsTab->Location = System::Drawing::Point(4, 22);
			this->BrandsTab->Name = L"BrandsTab";
			this->BrandsTab->Size = System::Drawing::Size(776, 395);
			this->BrandsTab->TabIndex = 3;
			this->BrandsTab->Text = L"Brands";
			this->BrandsTab->UseVisualStyleBackColor = true;
			// 
			// BrandsTextBox
			// 
			this->BrandsTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->BrandsTextBox->Location = System::Drawing::Point(0, 0);
			this->BrandsTextBox->Name = L"BrandsTextBox";
			this->BrandsTextBox->Size = System::Drawing::Size(776, 395);
			this->BrandsTextBox->TabIndex = 0;
			this->BrandsTextBox->Text = L"";
			// 
			// DepartmentsTab
			// 
			this->DepartmentsTab->Controls->Add(this->DepartmentsTextBox);
			this->DepartmentsTab->Location = System::Drawing::Point(4, 22);
			this->DepartmentsTab->Name = L"DepartmentsTab";
			this->DepartmentsTab->Padding = System::Windows::Forms::Padding(3);
			this->DepartmentsTab->Size = System::Drawing::Size(776, 395);
			this->DepartmentsTab->TabIndex = 0;
			this->DepartmentsTab->Text = L"Departments";
			this->DepartmentsTab->UseVisualStyleBackColor = true;
			// 
			// DepartmentsTextBox
			// 
			this->DepartmentsTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->DepartmentsTextBox->Location = System::Drawing::Point(3, 3);
			this->DepartmentsTextBox->Name = L"DepartmentsTextBox";
			this->DepartmentsTextBox->Size = System::Drawing::Size(770, 389);
			this->DepartmentsTextBox->TabIndex = 1;
			this->DepartmentsTextBox->Text = L"";
			// 
			// LocationsTab
			// 
			this->LocationsTab->Controls->Add(this->LocationsTextBox);
			this->LocationsTab->Location = System::Drawing::Point(4, 22);
			this->LocationsTab->Name = L"LocationsTab";
			this->LocationsTab->Size = System::Drawing::Size(776, 395);
			this->LocationsTab->TabIndex = 6;
			this->LocationsTab->Text = L"Locations";
			this->LocationsTab->UseVisualStyleBackColor = true;
			// 
			// ModelsTab
			// 
			this->ModelsTab->Controls->Add(this->ModelsTextBox);
			this->ModelsTab->Location = System::Drawing::Point(4, 22);
			this->ModelsTab->Name = L"ModelsTab";
			this->ModelsTab->Size = System::Drawing::Size(776, 395);
			this->ModelsTab->TabIndex = 2;
			this->ModelsTab->Text = L"Models";
			this->ModelsTab->UseVisualStyleBackColor = true;
			// 
			// StatusesTab
			// 
			this->StatusesTab->Controls->Add(this->StatusTextBox);
			this->StatusesTab->Location = System::Drawing::Point(4, 22);
			this->StatusesTab->Name = L"StatusesTab";
			this->StatusesTab->Size = System::Drawing::Size(776, 395);
			this->StatusesTab->TabIndex = 5;
			this->StatusesTab->Text = L"Status";
			this->StatusesTab->UseVisualStyleBackColor = true;
			// 
			// TypeTab
			// 
			this->TypeTab->Controls->Add(this->TypeTextBox);
			this->TypeTab->Location = System::Drawing::Point(4, 22);
			this->TypeTab->Name = L"TypeTab";
			this->TypeTab->Size = System::Drawing::Size(776, 395);
			this->TypeTab->TabIndex = 4;
			this->TypeTab->Text = L"MachineTypes";
			this->TypeTab->UseVisualStyleBackColor = true;
			// 
			// UsersTab
			// 
			this->UsersTab->Controls->Add(this->UserTextBox);
			this->UsersTab->Location = System::Drawing::Point(4, 22);
			this->UsersTab->Name = L"UsersTab";
			this->UsersTab->Padding = System::Windows::Forms::Padding(3);
			this->UsersTab->Size = System::Drawing::Size(776, 395);
			this->UsersTab->TabIndex = 1;
			this->UsersTab->Text = L"Users";
			this->UsersTab->UseVisualStyleBackColor = true;
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 1;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50)));
			this->tableLayoutPanel1->Controls->Add(this->tabControl1, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->tableLayoutPanel2, 0, 1);
			this->tableLayoutPanel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel1->Location = System::Drawing::Point(0, 0);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 2;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 90.10526F)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 9.894737F)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(790, 475);
			this->tableLayoutPanel1->TabIndex = 2;
			// 
			// tableLayoutPanel2
			// 
			this->tableLayoutPanel2->ColumnCount = 3;
			this->tableLayoutPanel2->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				100)));
			this->tableLayoutPanel2->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				150)));
			this->tableLayoutPanel2->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				150)));
			this->tableLayoutPanel2->Controls->Add(this->SaveButton, 1, 0);
			this->tableLayoutPanel2->Controls->Add(this->CloseButton, 2, 0);
			this->tableLayoutPanel2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tableLayoutPanel2->Location = System::Drawing::Point(3, 430);
			this->tableLayoutPanel2->Name = L"tableLayoutPanel2";
			this->tableLayoutPanel2->RowCount = 1;
			this->tableLayoutPanel2->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 100)));
			this->tableLayoutPanel2->Size = System::Drawing::Size(784, 42);
			this->tableLayoutPanel2->TabIndex = 2;
			// 
			// SaveButton
			// 
			this->SaveButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->SaveButton->Location = System::Drawing::Point(489, 5);
			this->SaveButton->Margin = System::Windows::Forms::Padding(5);
			this->SaveButton->Name = L"SaveButton";
			this->SaveButton->Size = System::Drawing::Size(140, 32);
			this->SaveButton->TabIndex = 0;
			this->SaveButton->Text = L"Save";
			this->SaveButton->UseVisualStyleBackColor = true;
			this->SaveButton->Click += gcnew System::EventHandler(this, &ListForm::SaveButton_Click);
			// 
			// CloseButton
			// 
			this->CloseButton->Dock = System::Windows::Forms::DockStyle::Fill;
			this->CloseButton->Location = System::Drawing::Point(639, 5);
			this->CloseButton->Margin = System::Windows::Forms::Padding(5);
			this->CloseButton->Name = L"CloseButton";
			this->CloseButton->Size = System::Drawing::Size(140, 32);
			this->CloseButton->TabIndex = 1;
			this->CloseButton->Text = L"Close";
			this->CloseButton->UseVisualStyleBackColor = true;
			this->CloseButton->Click += gcnew System::EventHandler(this, &ListForm::CloseButton_Click);
			// 
			// LocationsTextBox
			// 
			this->LocationsTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->LocationsTextBox->Location = System::Drawing::Point(0, 0);
			this->LocationsTextBox->Name = L"LocationsTextBox";
			this->LocationsTextBox->Size = System::Drawing::Size(776, 395);
			this->LocationsTextBox->TabIndex = 2;
			this->LocationsTextBox->Text = L"";
			// 
			// ModelsTextBox
			// 
			this->ModelsTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->ModelsTextBox->Location = System::Drawing::Point(0, 0);
			this->ModelsTextBox->Name = L"ModelsTextBox";
			this->ModelsTextBox->Size = System::Drawing::Size(776, 395);
			this->ModelsTextBox->TabIndex = 2;
			this->ModelsTextBox->Text = L"";
			// 
			// StatusTextBox
			// 
			this->StatusTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->StatusTextBox->Location = System::Drawing::Point(0, 0);
			this->StatusTextBox->Name = L"StatusTextBox";
			this->StatusTextBox->Size = System::Drawing::Size(776, 395);
			this->StatusTextBox->TabIndex = 2;
			this->StatusTextBox->Text = L"";
			// 
			// TypeTextBox
			// 
			this->TypeTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->TypeTextBox->Location = System::Drawing::Point(0, 0);
			this->TypeTextBox->Name = L"TypeTextBox";
			this->TypeTextBox->Size = System::Drawing::Size(776, 395);
			this->TypeTextBox->TabIndex = 2;
			this->TypeTextBox->Text = L"";
			// 
			// UserTextBox
			// 
			this->UserTextBox->Dock = System::Windows::Forms::DockStyle::Fill;
			this->UserTextBox->Location = System::Drawing::Point(3, 3);
			this->UserTextBox->Name = L"UserTextBox";
			this->UserTextBox->Size = System::Drawing::Size(770, 389);
			this->UserTextBox->TabIndex = 2;
			this->UserTextBox->Text = L"";
			// 
			// ListForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(790, 475);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Name = L"ListForm";
			this->Text = L"Lists";
			this->Load += gcnew System::EventHandler(this, &ListForm::ListForm_Load);
			this->tabControl1->ResumeLayout(false);
			this->BrandsTab->ResumeLayout(false);
			this->DepartmentsTab->ResumeLayout(false);
			this->LocationsTab->ResumeLayout(false);
			this->ModelsTab->ResumeLayout(false);
			this->StatusesTab->ResumeLayout(false);
			this->TypeTab->ResumeLayout(false);
			this->UsersTab->ResumeLayout(false);
			this->tableLayoutPanel1->ResumeLayout(false);
			this->tableLayoutPanel2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void ListForm_Load(System::Object^  sender, System::EventArgs^  e) {
		//Fill all boxes with data from the lists files
		//if no files exist
		fillContent(BrandsTextBox);
		fillContent(DepartmentsTextBox);
		fillContent(TypeTextBox);
		fillContent(StatusTextBox);
		fillContent(LocationsTextBox);
		fillContent(UserTextBox);
		fillContent(ModelsTextBox);
		
	}

	private: System::Void SaveButton_Click(System::Object^  sender, System::EventArgs^  e) {
		saveContent(BrandsTextBox);
		saveContent(DepartmentsTextBox);
		saveContent(TypeTextBox);
		saveContent(StatusTextBox);
		saveContent(LocationsTextBox);
		saveContent(UserTextBox);
		saveContent(ModelsTextBox);

		//Do the same for all the other tabs

	}
	public: System::Void saveContent(System::Windows::Forms::RichTextBox^ textBo) {
		String^ fileName;

		if (textBo->Name == "BrandsTextBox") {
			fileName = "data/lists/brandList.txt";
		}
		else if (textBo->Name == "DepartmentsTextBox") {
			fileName = "data/lists/deptList.txt";
		}
		else if (textBo->Name == L"TypeTextBox") {
			fileName = "data/lists/typeList.txt";
		}
		else if (textBo->Name == L"StatusTextBox") {
			fileName = "data/lists/statusList.txt";
		}
		else if (textBo->Name == L"LocationsTextBox") {
			fileName = "data/lists/locationList.txt";
		}
		else if (textBo->Name == L"UserTextBox") {
			fileName = "data/lists/userList.txt";
		}
		else if (textBo->Name == L"ModelsTextBox") {
			fileName = "data/lists/modelList.txt";
		}

		StreamWriter^ sw = gcnew StreamWriter(fileName);
		sw->WriteLine(textBo->Text);
		sw->Close();
		Console::WriteLine("a new file ('{0}') has been written", fileName);
	}



	public: System::Void fillContent(System::Windows::Forms::RichTextBox^ textB) {
		String^ fileName;
		if (textB->Name == "BrandsTextBox") {
			fileName = "data/lists/brandList.txt";
		}
		else if (textB->Name == "DepartmentsTextBox") {
			fileName = "data/lists/deptList.txt";
		}
		else if (textB->Name == L"TypeTextBox") {
			fileName = "data/lists/typeList.txt";
		}
		else if (textB->Name == L"StatusTextBox") {
			fileName = "data/lists/statusList.txt";
		}
		else if (textB->Name == L"LocationsTextBox") {
			fileName = "data/lists/locationList.txt";
		}
		else if (textB->Name == L"UserTextBox") {
			fileName = "data/lists/userList.txt";
		}
		else if (textB->Name == L"ModelsTextBox") {
			fileName = "data/lists/modelList.txt";
		}


		if (!File::Exists(fileName))
		{
			return;
		}	
		StreamReader^ sr = File::OpenText(fileName);
		String^ input;
		String ^ str;
		while ((input = sr->ReadLine()) != nullptr)
		{
			if (!sr->EndOfStream) {
				str = input + "\n" + str;
			}	
			else if (sr->EndOfStream) {
				str = str + input;
			}
		}
		sr->Close();
		textB->Text = str;
}


private: System::Void CloseButton_Click(System::Object^  sender, System::EventArgs^  e) {
	Close();
}
};
}
