#include "AddNewMachineWindow.h"

